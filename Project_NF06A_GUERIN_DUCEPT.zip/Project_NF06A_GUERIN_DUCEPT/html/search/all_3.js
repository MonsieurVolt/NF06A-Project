var searchData=
[
  ['dataarray_0',['dataArray',['../get__data_8py.html#a428023b953c009b4f16803435b193f9e',1,'get_data']]],
  ['date_1',['date',['../structdate.html',1,'date'],['../classget__data_1_1date.html',1,'get_data.date']]]
];
