var searchData=
[
  ['getdate_0',['GetDate',['../get__data_8py.html#a77b47b1d494b2a4fa5e61a5764809561',1,'get_data']]]
];
