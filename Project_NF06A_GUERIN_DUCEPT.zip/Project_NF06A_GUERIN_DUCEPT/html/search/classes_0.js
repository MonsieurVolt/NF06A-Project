var searchData=
[
  ['date_0',['date',['../structdate.html',1,'date'],['../classget__data_1_1date.html',1,'get_data.date']]]
];
