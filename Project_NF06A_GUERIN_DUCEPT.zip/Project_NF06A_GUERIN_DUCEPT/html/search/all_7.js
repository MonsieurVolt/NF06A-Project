var searchData=
[
  ['handledate_0',['HandleDate',['../get__data_8py.html#a7230a2f3117d3a422bb434c341bfd88b',1,'get_data']]]
];
