var searchData=
[
  ['find_5fid_0',['find_id',['../get__data_8py.html#a026ecd8c9edcc118aa843106bcac7008',1,'get_data']]]
];
