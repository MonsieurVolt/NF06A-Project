var searchData=
[
  ['get_5fdata_2epy_0',['get_data.py',['../get__data_8py.html',1,'']]],
  ['getdate_1',['GetDate',['../get__data_8py.html#a77b47b1d494b2a4fa5e61a5764809561',1,'get_data']]]
];
