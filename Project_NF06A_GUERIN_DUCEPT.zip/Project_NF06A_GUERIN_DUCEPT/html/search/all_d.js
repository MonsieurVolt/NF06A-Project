var searchData=
[
  ['print_5fdatas_0',['print_datas',['../get__data_8py.html#adea0cc07ad07cf7286767388b154185a',1,'get_data']]],
  ['prtf_5fcalculation_1',['prtf_calculation',['../cfile_8c.html#a00039651e3a350ccbcd6a80efe444531',1,'cfile.c']]]
];
