var searchData=
[
  ['_5f_5fdeclspec_0',['__declspec',['../cfile_8c.html#ace782387dccc59824c26bc22e7bba792',1,'cfile.c']]]
];
