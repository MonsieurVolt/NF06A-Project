var searchData=
[
  ['idname_0',['idName',['../get__data_8py.html#a8299e19405a2a9e168d6c1b2e2b63a00',1,'get_data']]]
];
