var searchData=
[
  ['choice_0',['choice',['../main_8py.html#a64aa1885eb5b796c96a96cc4f3c7289a',1,'main']]]
];
