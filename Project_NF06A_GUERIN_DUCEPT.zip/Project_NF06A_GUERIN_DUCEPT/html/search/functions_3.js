var searchData=
[
  ['exit_0',['Exit',['../get__data_8py.html#aaec736b5b6eb5b4514cf2ff2ccf7f96a',1,'get_data']]]
];
