var indexSectionsWithContent =
{
  0: "_acdefghijlmnprs",
  1: "dj",
  2: "cgm",
  3: "_acefghprs",
  4: "cdeil",
  5: "ns"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Pages"
};

