var searchData=
[
  ['job_0',['job',['../classget__data_1_1job.html',1,'get_data.job'],['../structjob.html',1,'job']]]
];
